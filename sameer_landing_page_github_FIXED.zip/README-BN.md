# Sameer Khan [2014] — GitHub Pages

## গুরুত্বপূর্ণ: ZIP ফাইলটি সরাসরি GitHub-এ আপলোড করবেন না
প্রথমে ZIP Extract/Unzip করুন। তারপর Repository-র মূল ফোল্ডারে (root) নিচের ফাইল দুটো আলাদাভাবে আপলোড করুন:

- `index.html`
- `reference-poster.png`

দুটো ফাইল একই স্তরে থাকতে হবে; কোনো সাবফোল্ডারের ভেতরে নয়।

## GitHub Pages চালু করা
1. Repository → Settings → Pages
2. Build and deployment → Source: `Deploy from a branch`
3. Branch: `main`
4. Folder: `/(root)`
5. Save চাপুন এবং কয়েক মিনিট অপেক্ষা করুন।

Repository name যদি `sameer-khan-landing` হয়, সাইটের ঠিকানা হবে:
`https://YOUR-USERNAME.github.io/sameer-khan-landing/`

Telegram Join বাটনে আপনার দেওয়া invite link যুক্ত আছে:
`https://t.me/+YdRkhD86u2w1NzRl`
